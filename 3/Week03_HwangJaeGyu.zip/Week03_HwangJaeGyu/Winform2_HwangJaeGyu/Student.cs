﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Winform2_HwangJaeGyu
{
    /*
     *class == struct + method
     *
     *struct Student
        {
        char Number[10];
        char Name[100];
        double Score;
        }
     */
    internal class Student  //c언어의 struct == 사용자정의타입
    {
        //인스턴스 변수
        public string Number;
        public string Name;
        public double Score;
    }

}
